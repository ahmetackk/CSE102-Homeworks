Yetiştiremediğim için maalessef output yok.
Ödev pdf inde istenen tüm fonksiyonlar mevcut ve çalışır halde.
Veri tabanı gibi yapmaya çalıştığımdan menülerler oynayarak fonksiyonları test edebilirsiniz ( Biraz karmaşık oldu denemek istediğiniz
özelliği kodda bulup menüde oraya giderseniz daha kolay olur)
Kodda fazla yorum satırı bulunmuyor karmaşık olan yerlere koydum, fazladan kullanım için eklediğim fonksiyonları isimlerinden anlaşılabilecek
şekilde yapmaya çalıştım.